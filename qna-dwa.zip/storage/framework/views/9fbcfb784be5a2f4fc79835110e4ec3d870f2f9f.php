<?php $__env->startSection('content'); ?>
<div class="container">
    <table id="data" class="table table-striped table-bordered" style="width:100%; background:#fff; font-size:12px;">
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Browser</th>
                <th>Device</th>
                <th>OS</th>
                <th>Chart</th>
                <th>Communication LV</th>
                <th>Water Quality</th>
                <th>Education</th>
                <th>Age</th>
                <th>Question</th>
                <th>Value</th>
            </tr>
        </thead>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dedenbangkit/Sites/qna-dwa/resources/views/home.blade.php ENDPATH**/ ?>